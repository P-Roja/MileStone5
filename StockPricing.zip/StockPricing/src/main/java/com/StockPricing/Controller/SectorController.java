package com.StockPricing.Controller;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.StockPricing.model.Company;
import com.StockPricing.model.Sector;
import com.StockPricing.model.StockExchange;
import com.StockPricing.service.SectorService;
import com.StockPricing.service.StockExchangeService;

@Controller
public class SectorController {
	@Autowired
	private SectorService sectorService;

	@RequestMapping("/insertSector")
	public ModelAndView insertSector(ModelMap map) {
		ModelAndView mav = null;
		map.addAttribute("sector", new Sector());
		mav = new ModelAndView("SectorInsert");
		return mav;

	}

	@RequestMapping(value = "/insertSector", method = RequestMethod.POST)
	public ModelAndView insertSector(@ModelAttribute("sector") @Valid Sector sector, BindingResult result,
			HttpServletRequest request,ModelMap map) throws SQLException {
		ModelAndView mav = null;
		if (result.hasErrors()) {
			mav = new ModelAndView("SectorInsert");
			return mav;
		}
		sectorService.insertSector(sector);
		ArrayList sectorDetails = (ArrayList) sectorService.getSectorList();
		map.addAttribute("sectorList", sectorDetails);
		mav = new ModelAndView("SectorList");
		return mav;

	}

	@RequestMapping(path = "/sectorList")
	public ModelAndView getSectorList(ModelMap map) throws Exception {
		ModelAndView mav = new ModelAndView();
		ArrayList sectorDetails = (ArrayList) sectorService.getSectorList();
		map.addAttribute("sectorList", sectorDetails);
		mav = new ModelAndView("SectorList");
		return mav;
	}

	@RequestMapping("/sectorUpdate")
	public ModelAndView sectorUpdation(@RequestParam("id") int sectorId, ModelMap map, HttpServletRequest request,
			@ModelAttribute("sector") Sector sector) throws ClassNotFoundException, SQLException {
		ModelAndView mav = null;
		sector = sectorService.fetchSectorUpdate(sectorId);

		map.addAttribute("update", sector);
		mav = new ModelAndView("SectorUpdate");
		return mav;

	}

	@RequestMapping(value = "/updateSector", method = RequestMethod.POST)
	public ModelAndView updateSector(HttpServletRequest request, ModelMap map,
			@ModelAttribute("sector") Sector sector, BindingResult result) throws ClassNotFoundException, SQLException {
		int sectorId = sector.getSectorId();
		ModelAndView mav = null;
		ArrayList sectorDetails = null;

		if (result.hasErrors()) {
			Sector sector1 = new Sector();
			sector1 = sector = sectorService.fetchSectorUpdate(sectorId);
			map.addAttribute("update", sector1);
			mav = new ModelAndView("SectorUpdate");
			return mav;
		}
		sectorService.updateSector(sector);

		sectorDetails = (ArrayList) sectorService.getSectorList();
		map.addAttribute("sectorList", sectorDetails);
		mav = new ModelAndView("SectorList");
		return mav;

	}
}
