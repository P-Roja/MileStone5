package com.StockPricing.Controller;

import java.sql.SQLException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.StockPricing.model.Company;
import com.StockPricing.model.User;
import com.StockPricing.service.UserService;

@Controller
public class UserController {
	@Autowired
	private UserService userService;

	@RequestMapping("/registerUser")
	public ModelAndView insertUser(ModelMap map) throws SQLException {
		ModelAndView mav = null;
		map.addAttribute("user", new User());

		mav = new ModelAndView("UserRegistration");
		return mav;

	}

	@RequestMapping("/logout")
	public ModelAndView loginPage(ModelMap map) {
		ModelAndView mav = null;
		map.addAttribute("user", new User());
		mav = new ModelAndView("Login");
		return mav;

	}

	@RequestMapping(value = "/registerUser", method = RequestMethod.POST)
	public ModelAndView registerUSer(@ModelAttribute("user") @Valid User user, BindingResult result,
			HttpServletRequest request,ModelMap map) throws SQLException {
		ModelAndView mav = null;
		if (result.hasErrors()) {
			mav = new ModelAndView("UserRegistration");
			return mav;
		}
		userService.registerUser(user);
		mav = new ModelAndView("redirect:/loginAdmin");
		return mav;

	}

	@RequestMapping(path = "/loginAdmin", method = RequestMethod.POST)
	public ModelAndView registerCompany(@ModelAttribute("user") @Valid User user, BindingResult result,
			HttpServletRequest request, ModelMap map) throws SQLException {

		ModelAndView mav = null;

		String username = user.getUsername();

		List<User> user1 = userService.findByUsername(username);

		User user2 = user1.get(0);
		System.out.println(user.getUsername() + " " + user2.getUsername());

		System.out.println(user.getPassword() + " " + user2.getPassword());
		if ((user.getUsername().equals(user2.getUsername())) && (user.getPassword().equals(user2.getPassword()))) {

			if (user2.getUserType().equals("Admin")) {
				mav = new ModelAndView("AdminLandingPage");
			} else {
				mav = new ModelAndView("UserLandingPage");
			}
		} else {

			mav = new ModelAndView("login", "message", "Invalid Username or Password");
		}

		return mav;

	}
}
