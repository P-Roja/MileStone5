package com.StockPricing.Dao;

public class StockPriceDaoImpl {

}
