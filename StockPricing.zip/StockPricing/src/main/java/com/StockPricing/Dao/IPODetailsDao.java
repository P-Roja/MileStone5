package com.StockPricing.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.StockPricing.model.IPODetails;

public interface IPODetailsDao extends JpaRepository<IPODetails, Integer> {
	public List<IPODetails> findByCompanyCode(int companyCode);

	/* public IPODetails findByCompanyCode(int companyCode) ; */
}
