
package com.StockPricing.service;

import java.sql.SQLException;
import java.util.List;

import org.springframework.stereotype.Service;

import com.StockPricing.model.Company;
import com.StockPricing.model.Sector;
import com.StockPricing.model.StockExchange;

public interface SectorService {
	public List<Sector> getSectorList() throws SQLException;

	public void insertSector(Sector sector) throws SQLException;

	public void updateSector(Sector sector) throws SQLException;

	public Sector fetchSectorUpdate(int sectorId) throws SQLException, ClassNotFoundException;
}
