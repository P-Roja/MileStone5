package com.StockPricing.service;

import java.sql.SQLException;
import java.util.List;

import com.StockPricing.model.User;

public interface UserService {
	public void registerUser(User user) throws SQLException;

	public List<User> findByUsername(String username);

}
